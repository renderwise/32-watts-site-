<?php
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$phone = $_REQUEST['mobile'];


$to = 'narayan@alignwisesmile.com,nikgupta2701@gmail.com,deepakclearaligner@gmail.com';
$subject = 'You Have new Lead from 32watts.com';

$body = "";
$body .= "Name: ";
$body .= $name;
$body .= "\n\n";

$body .= "";
$body .= "Email: ";
$body .= $email;
$body .= "\n\n";

$body .= "";
$body .= "Phone no.: ";
$body .= $phone;
$body .= "\n";


$headers = 'From: ' .LandingpageLeads . "\r\n";

if (filter_var($to, FILTER_VALIDATE_EMAIL)) {
mail($to, $subject, $body, $headers);
echo '<span id="valid">Thank you, We will Get Back to you as soon as possible</span>';
}else{
echo '<span id="invalid">Something gets wrong. Please try again.</span>';
}